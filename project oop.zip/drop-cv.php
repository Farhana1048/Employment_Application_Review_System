<?php session_start();
	require_once('functions/function.php');
	needLogged();
	get_part('header.php');
	$id=$_GET['a'];        
	$sel="select * from job_circuler where job_id='$id'";
	$qry=mysqli_query($con,$sel);
	$data=mysqli_fetch_array($qry);
        
        
        	if(isset($_POST['send'])){
                //$jobid=$_POST['jobid'];  
                $date = date('Y-m-d H:i:s');
                $photo=$_FILES['cv'];
		$ImageName='user-'.time().'-'.md5(rand(10000,100000)).'.'.pathinfo($photo['name'],PATHINFO_EXTENSION);

		$insert="INSERT INTO applicants_cv(applicant_name,cv_file,drop_time)VALUES('{$_SESSION['user']}','$ImageName','$date')";
                if(mysqli_query($con,$insert)){
                        if($ImageName!=''){
                        move_uploaded_file($photo['tmp_name'], 'uploads/'.$ImageName);
                        echo 'Success!';
			header('Location: all-circuler.php');
                     }
                    
	}else{
            echo "User update failed!!!";
            }
        }
        
?>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <div class="col-sm-9">
                <strong>Drop CV</strong>
            </div>
            <div class="col-sm-3">
                <a href="#" class="amar_btn"> <i class="fa fa-plus-square"></i> All User</a>
            </div>
            <div class="clearfix"></div>
          </div>
          <div class="panel-body">
            <form class="form-horizontal" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <label class="col-sm-3 control-label">Job ID<span class="req_span">*</span></label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="jobid" value="<?=$data['job_id']; ?>" disabled="disabled">
                </div>
              </div>     

			  
			  
			       <div class="form-group">
                <label class="col-sm-3 control-label">Job Post<span class="req_span">*</span></label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="jobid" value="<?=$data['job_title']; ?>" disabled="disabled">
                </div>
              </div> 
			  
			  
			  
			  
              <div class="form-group">
                <label for="" class="col-sm-3 control-label">CV</label>
                <div class="col-sm-8">
                    <input type="file" class="" id="" name="cv">
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-3"></div>
                <div class="col-sm-8">
                    <input type="submit" class="btn btn-default" name="send" value="SEND">
                </div>
              </div>
            </form>
          </div>
          <div class="panel-footer">
            .
          </div>
        </div>
    </div>
</div>
<?php
	get_part('footer.php');
?>