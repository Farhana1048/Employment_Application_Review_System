-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2017 at 09:19 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ears`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `app_id` int(11) NOT NULL,
  `app_name` varchar(200) NOT NULL,
  `app_username` varchar(200) NOT NULL,
  `app_email` varchar(100) NOT NULL,
  `app_phone` varchar(50) NOT NULL,
  `app_password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`app_id`, `app_name`, `app_username`, `app_email`, `app_phone`, `app_password`) VALUES
(1, 'Rafikul Islam', 'rafikul', 'rafi@gmail.com', '01729346959', '202cb962ac59075b964b07152d234b70'),
(2, 'Khalid Hasan Hemal', 'hemel', 'hemal@gmail.com', '01700000000', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `applicants_cv`
--

CREATE TABLE `applicants_cv` (
  `cv_id` int(11) NOT NULL,
  `applicant_name` varchar(200) NOT NULL,
  `job_id` int(11) NOT NULL,
  `cv_file` varchar(200) NOT NULL,
  `drop_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicants_cv`
--

INSERT INTO `applicants_cv` (`cv_id`, `applicant_name`, `job_id`, `cv_file`, `drop_time`) VALUES
(1, 'rafikul', 1, 'user-1512676098-817fc6c6956366b3bec166a1bbca944a.docx', '2017-12-07 20:48:18');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_users`
--

CREATE TABLE `faculty_users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role_id` int(11) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_users`
--

INSERT INTO `faculty_users` (`id`, `name`, `email`, `phone`, `username`, `password`, `role_id`, `photo`) VALUES
(1, 'Rafikul Islam', 'rafi@gmail.com', '0186396523', 'rafi', '202cb962ac59075b964b07152d234b70', 1, 'user-1512677917-75d138db348423ceefe73a9b104f85b8.jpg'),
(2, 'Farhana Alam Shawlin', 'shawlin@gmail.com', '01700000000', 'shawlin', '202cb962ac59075b964b07152d234b70', 2, 'user-1512672172-01d5fe9395cb06bd35475b88f6647d32.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `job_category`
--

CREATE TABLE `job_category` (
  `jcate_id` int(11) NOT NULL,
  `jcate_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_category`
--

INSERT INTO `job_category` (`jcate_id`, `jcate_name`) VALUES
(1, 'IT/Telecommunication'),
(2, 'Medical/Pharma');

-- --------------------------------------------------------

--
-- Table structure for table `job_circuler`
--

CREATE TABLE `job_circuler` (
  `job_id` int(11) NOT NULL,
  `job_title` varchar(200) NOT NULL,
  `job_qualification` text NOT NULL,
  `jcate_id` int(11) NOT NULL,
  `job_deadline` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_circuler`
--

INSERT INTO `job_circuler` (`job_id`, `job_title`, `job_qualification`, `jcate_id`, `job_deadline`) VALUES
(1, 'Senior Software Engineer', 'B.Sc in software Engineering at any reputed univarsity', 1, '2017-12-22 00:00:00'),
(2, 'Medical Asistant', 'Diploma In MATS', 2, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `u_category`
--

CREATE TABLE `u_category` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `u_category`
--

INSERT INTO `u_category` (`role_id`, `role_name`) VALUES
(1, 'Admin'),
(2, 'Faculty');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `applicants_cv`
--
ALTER TABLE `applicants_cv`
  ADD PRIMARY KEY (`cv_id`),
  ADD KEY `job_id` (`job_id`);

--
-- Indexes for table `faculty_users`
--
ALTER TABLE `faculty_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_category_id` (`role_id`);

--
-- Indexes for table `job_category`
--
ALTER TABLE `job_category`
  ADD PRIMARY KEY (`jcate_id`);

--
-- Indexes for table `job_circuler`
--
ALTER TABLE `job_circuler`
  ADD PRIMARY KEY (`job_id`),
  ADD KEY `jcate_id` (`jcate_id`);

--
-- Indexes for table `u_category`
--
ALTER TABLE `u_category`
  ADD PRIMARY KEY (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `applicants_cv`
--
ALTER TABLE `applicants_cv`
  MODIFY `cv_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `faculty_users`
--
ALTER TABLE `faculty_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `job_category`
--
ALTER TABLE `job_category`
  MODIFY `jcate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `job_circuler`
--
ALTER TABLE `job_circuler`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `u_category`
--
ALTER TABLE `u_category`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `applicants_cv`
--
ALTER TABLE `applicants_cv`
  ADD CONSTRAINT `applicants_cv_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job_circuler` (`job_id`);

--
-- Constraints for table `faculty_users`
--
ALTER TABLE `faculty_users`
  ADD CONSTRAINT `faculty_users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `u_category` (`role_id`);

--
-- Constraints for table `job_circuler`
--
ALTER TABLE `job_circuler`
  ADD CONSTRAINT `job_circuler_ibfk_1` FOREIGN KEY (`jcate_id`) REFERENCES `job_category` (`jcate_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
