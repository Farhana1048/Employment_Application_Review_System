<?php 
    require_once("functions/function.php");
    get_part('header.php');
    get_part('slider.php');
    
    	if(isset($_POST['send'])){
		$name=htmlentities($_POST['name'],ENT_QUOTES);
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$username=$_POST['username'];
		$password=md5($_POST['pass']);		
		if(empty($username)||(empty($password))){
			echo"<script>window.alert('please fill up the required fields!!')</script>";
 			exit();
			}
		else{	
		$insert="INSERT INTO applicants(app_name,app_email,app_phone,app_username,app_password)VALUES('$name','$email','$phone','$username','$password')";
		$qry=mysqli_query($con,$insert);
		if($qry){
			
			 header('Location: index.php');
			}
			else{
				 echo"window.alert('Product insert Failed!!')";
				}
		}
	}
?>

<!--start registration-->
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <div class="col-sm-9">
                <strong>User Registration</strong>
            </div>
            <div class="col-sm-3">
                <a href="all-user.php" class="amar_btn"> <i class="fa fa-plus-square"></i> All User</a>
            </div>
            <div class="clearfix"></div>
          </div>
          <div class="panel-body">
            <form class="form-horizontal" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Name<span class="req_span">*</span></label>
                <div class="col-sm-8">
                  <input type="text" name="name" class="form-control" id="inputEmail3" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Email<span class="req_span">*</span></label>
                <div class="col-sm-8">
                  <input type="email" name="email" class="form-control" id="inputEmail3" placeholder="">
                </div>
              </div>
               <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Phone</label>
                <div class="col-sm-8">
                  <input type="text" name="phone" class="form-control" id="inputEmail3" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Username<span class="req_span">*</span></label>
                <div class="col-sm-8">
                  <input type="text" name="username" class="form-control" id="inputEmail3" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Password<span class="req_span">*</span></label>
                <div class="col-sm-8">
                  <input type="password" name="pass" class="form-control" id="inputEmail3" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label">Re-Password<span class="req_span">*</span></label>
                <div class="col-sm-8">
                  <input type="password" class="form-control" id="inputEmail3" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-3"></div>
                <div class="col-sm-8">
                    <input type="submit" class="btn btn-default" name="send" value="REGISTRATION">
                </div>
              </div>
            </form>
          </div>
          <div class="panel-footer">
            .
          </div>
        </div>
    </div>
</div>
<!--end registration-->

<?php 
    get_part('footer.php');
?>	