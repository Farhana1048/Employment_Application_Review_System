<?php session_start();
    require_once("functions/function.php");
    get_part('header.php');
?>	
<br>
<div class="container-fluid">
		<div class="container">
			<div class="row">
				<h3 class="text-center">Login Here</h3>
                        <?php
                        	if(!empty($_POST)){
								$name=$_POST['username'];
								$pass=md5($_POST['password']);
								$sel="SELECT * FROM applicants WHERE app_username='$name' AND app_password='$pass'";
								$qry=mysqli_query($con, $sel);
								$res=mysqli_fetch_array($qry);
								if($res){
									$_SESSION['name']=$res['app_name'];
									$_SESSION['user']=$res['app_username'];
									header('location: all-circuler.php');
								}else{
									echo "Username and Password incorrect!!!";	
									}
								}
			?>

                                
				<form class="form-horizontal" method="post">
					<div class="form-group">
						<div class="col-xs-3 text-right">
							User Name
						</div>
						<div class="col-xs-6">
							<input type="text" name="username" placeholder="username" class="form-control">
						</div>
					</div>
					<div class="form-group">
						<div class="col-xs-3 text-right">
							Password
						</div>
						<div class="col-xs-6">
							<input type="password" name="password" placeholder="password" class="form-control">
						</div>
					</div>
					<div class="form-group">
						<div class="col-xs-3 text-right">
                                                    <a class="btn btn-success" href="registration.php">Registration</a>
						</div>
						<div class="col-xs-6">
							<input type="submit" name="" value="login" class="btn btn-success">
						</div>

					</div>
				</form>
			</div>
		</div>
        </div><br>
<?php 
    get_part('footer.php');
?>