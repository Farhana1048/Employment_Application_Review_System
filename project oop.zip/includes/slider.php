<!--start slider-->
<div class="container-fluid" style="margin-top: -20px;">
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <img src="image/slider-1.jpg" class="img-responsive">
              <div class="carousel-caption">
                <h3>Loking For job ??  </h3>
                <p>APPLY NOW</p>
              </div>
            </div>
          </div>
        </div>
</div>	
<br>
<!--end slider-->