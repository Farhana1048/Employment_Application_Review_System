
	<footer class="footer" style="margin-top: -20px;">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<ul>
						<li> <a href="">About Us</a></li>
						<li> <a href="">Contact Us</a></li>
						<li> <a href="">Our Goal</a></li>
					</ul>
				</div>
				<div class="col-md-4">
					<ul>
						<li> <a href="">Trams & Condition</a></li>
						<li> <a href="">Get Help</a></li>
						<li> <a href="">Our Blog</a></li>

					</ul>
				</div>
				<div class="col-md-4">
					<h4 class="address"><span class="glyphicon glyphicon-home"></span> Address</h4>
					<address>
						Sukrabad, Dhanmondi 32,<br>
						Dhaka Bangladesh.
					</address>
				</div>
			</div>
		</div>
	</footer>

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>