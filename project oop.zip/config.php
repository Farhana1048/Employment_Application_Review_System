<?php
	$con=mysqli_connect("localhost","root","","ears");
	if(!$con){
		echo "connection error";
		}
?>