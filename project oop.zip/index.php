<?php 
    require_once("functions/function.php");
    get_part('header.php');
?>
	
	<div class="container-fluid" style="margin-top: -20px;">
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
			    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
			    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
			  </ol>
			  <div class="carousel-inner" role="listbox">
			    <div class="item active">
			      <img src="image/slider-6.jpg" class="img-responsive">
			      <div class="carousel-caption">
			        <h3>Find your job </h3>
			        <p>Job search...</p>
			      </div>
			    </div>
			    <div class="item">
			      <img src="image/slider-2.jpg" class="img-responsive">
			      <div class="carousel-caption">
			          <h3>Find best Employee </h3>
			        <p>Job search...</p>
			      </div>
			    </div>
			    <div class="item">
			      <img src="image/slider-3.jpg" class="img-responsive">
			      <div class="carousel-caption">
			          <h3>Find your job </h3>
			        <p>Job search...</p>
			      </div>
			    </div>
				
			  </div>

			  <!-- Controls -->
			  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
			    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			    <span class="sr-only">Previous</span>
			  </a>
			  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
			    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			    <span class="sr-only">Next</span>
			  </a>
			</div>
        </div><br>
<!--end slider-->
<!--start search-->
	<div class="container-fluid well" style="padding: 40px 0px 20px 0px;">
		<div class="container">
			<div class="row">
			<h1  class="text-center"> Employment Application Review System </h1>
				<h3 class="text-center"> Find your JOB</h3>
				<form class="form-horizontal">
					<div class="form-group">
						<div class="col-xs-2"></div>
						<div class="col-xs-6">
							<input type="text" name="employee" class="form-control" placeholder="search Here">
						</div>
						<div class="col-xs-2">
							<button type="submit" class="btn btn-info">Search</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
<!--end search-->
<!--start content-->
<div class="row">
                <?php
                	$sel="select * from job_circuler natural join job_category order by job_id desc";
			$qry=mysqli_query($con,$sel);
			while($data=mysqli_fetch_array($qry)){
		?> 
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
        <h2>IT/Telecommunication</h2>      
      <div class="caption">
          <h3>Job ID: 01<br> Position:Senior Software Engineer</h3>
        <p>Education: BSc in Software Engineering at any reputed Univarsity</p>
        <h4>Deadline: 2017-12-22 00:00:00</h4>
        <p><a class="btn btn-sm btn-success" href="drop-cv.php?a=<?= $data['job_id']; ?>">Apply</a></p>
      </div>
                        
    </div>
  </div>
                <?php };?>
</div>

<div class="row">
                <?php
                	$sel="select * from job_circuler natural join job_category order by job_id desc";
			$qry=mysqli_query($con,$sel);
			while($data=mysqli_fetch_array($qry)){
		?> 
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
        <h2>IT/Telecommunication</h2>      
      <div class="caption">
          <h3>Job ID: 01<br> Position:Senior Software Engineer</h3>
        <p>Education: BSc in Software Engineering at any reputed Univarsity</p>
        <h4>Deadline: 2017-12-22 00:00:00</h4>
        <p><a class="btn btn-sm btn-success" href="drop-cv.php?a=<?= $data['job_id']; ?>">Apply</a></p>
      </div>
                        
    </div>
  </div>
                <?php };?>
</div>
<!--end content-->

<?php 
    get_part('footer.php');
?>