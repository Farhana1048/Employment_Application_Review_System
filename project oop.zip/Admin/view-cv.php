<?php session_start();
	require_once('function/function.php');
	needLogged();
	get_part('header.php');
	get_part('sidebar.php');
	get_part('bread.php');
	$id=$_GET['v'];
	$sel="select * from job_circuler where job_id='$id'";
	$qry=mysqli_query($con,$sel);
	$data=mysqli_fetch_array($qry);
?>
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="col-md-9 heading_title">
                    All CV For ID <strong><?= $data['job_id']; ?> <?= $data['job_title']; ?> </strong>
                </div>
                <div class="col-md-3 text-right">
                    <a href="all-circuler.php" class="btn btn-sm btn btn-primary"><i class="fa fa-plus-circle"></i> All Circuler</a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="panel-body">
                <table class="table table-responsive table-striped table-hover table_cus">
                    <thead class="table_head">
                        <tr>
                            <th>Applicant Name</th>
                           
                            <th>CV File</th>
                            <th>Job Category</th>
                            <th>Deadline</th>
                                                       
                            <th>Manage</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        $sel = 'SELECT * FROM applicants_cv NATURAL JOIN job_circuler ORDER BY cv_id DESC';
                        $qry = mysqli_query($con,$sel);
                        while($data =mysqli_fetch_array($qry)) {
                    ?>
                            <tr>
                                <td><?= $data['applicant_name']; ?></td>
                                
                                <td><?= substr($data['cv_file'], 0, 20); ?>...</td>
                                <td><?= $data['jcate_id']; ?></td>
                                <td><?= $data['job_deadline']; ?></td>                            
                                <td>
                                    <a href="view-cv.php?v=<?=$data['job_id'];?>" class="btn btn-info">View</a> 
                                    <a href="#" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div><!--col-md-12 end-->
<?php
	get_part('footer.php');
?>