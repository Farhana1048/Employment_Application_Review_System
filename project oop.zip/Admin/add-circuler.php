<?php session_start();
require_once('function/function.php');
needLogged();
    get_part('header.php');
    get_part('sidebar.php');
    get_part('bread.php');
    if (!empty($_POST)) {
        $title = $_POST['title'];
        $details = $_POST['details'];
        $pcate = $_POST['category'];
        
        if (!empty($title)) {
           
                $insert = "INSERT INTO job_circuler(job_title,job_qualification,jcate_id)"
                        . "VALUES('$title','$details','$pcate')";
                if (mysqli_query($con, $insert)) {
                    header ('location: all-circuler.php');
                } else {
                    echo "Upload Failed!";
                }
          
        } else {
            echo "Please enter banner title!";
        }
    }
    ?>
    <div class="col-md-12">
        <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="col-md-9 heading_title">
                        Add Circuler
                    </div>
                    <div class="col-md-3 text-right">
                        <a href="all-circuler.php" class="btn btn-sm btn btn-primary"><i class="fa fa-th"></i> All Circuler</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Job Title</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="title">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="col-sm-3 control-label">Qualification</label>
                        <div class="col-sm-8">
                            <textarea name="details" class="form-control" id=""  rows="5" placeholder="Details"></textarea>
                        </div>
                    </div>
              <div class="form-group">
                <label for="" class="col-sm-3 control-label">Category</label>
                <div class="col-sm-5">
                      <select name="category" class="form-control">
                       <?php  
				$sel="SELECT * FROM job_category";
				$qry=mysqli_query($con,$sel);
				while($per=mysqli_fetch_array($qry)){
			?>
                        	<option value="<?= $per['jcate_id'];?>"><?= $per['jcate_name'];?></option>
                        <?php }?>
                      </select>
                </div>
              </div>                    
                </div>
              <div class="form-group">
                <div class="col-sm-3"></div>
                <div class="col-sm-8">
                    <input type="submit" class="btn btn-sm btn-primary" name="send" value="UPLOAD">
                </div>
              </div>
               <!-- <div class="panel-footer text-center">
                    <button class="btn btn-sm btn-primary">UPLOAD</button>
                </div>-->
            </div>
        </form>
    </div><!--col-md-12 end-->
    <?php
     get_part('footer.php');
?>